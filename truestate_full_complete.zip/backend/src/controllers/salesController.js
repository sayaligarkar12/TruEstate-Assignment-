const QueryService = require('../services/queryService');

// GET /api/sales
exports.getSales = async (req, res) => {
  try {
    // Accept query parameters: search, filters (json), sort, page
    const { q, page = 1, pageSize = 10, sort } = req.query;
    // filters sent as JSON string
    const filters = req.query.filters ? JSON.parse(req.query.filters) : {};

    const result = await QueryService.query({ search: q, filters, sort, page: Number(page), pageSize: Number(pageSize) });
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};
