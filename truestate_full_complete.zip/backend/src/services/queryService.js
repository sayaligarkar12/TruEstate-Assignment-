const fs = require('fs');
const path = require('path');
const _ = require('lodash');

// Lazy-load dataset
let DATA = null;
function loadData() {
  if (DATA) return DATA;
  const file = path.join(__dirname, '..', '..', 'data', 'sales.json');
  if (!fs.existsSync(file)) throw new Error('Dataset not found: ' + file);
  const raw = fs.readFileSync(file, 'utf8');
  DATA = JSON.parse(raw);
  return DATA;
}

function normalize(str = '') {
  return String(str).toLowerCase().trim();
}

function applySearch(items, q) {
  if (!q) return items;
  const term = normalize(q);
  return items.filter(item => {
    const name = normalize(item.customerName || item.CustomerName || '');
    const phone = normalize(item.phoneNumber || item.PhoneNumber || '');
    return name.includes(term) || phone.includes(term);
  });
}

function applyFilters(items, filters) {
  // filters: { regions: [], genders: [], ageRange: [min,max], categories: [], tags: [], paymentMethods: [], dateFrom, dateTo }
  let out = items;
  if (!filters) return out;

  if (filters.regions && filters.regions.length) {
    out = out.filter(i => filters.regions.includes(i.customerRegion || i.CustomerRegion));
  }
  if (filters.genders && filters.genders.length) {
    out = out.filter(i => filters.genders.includes(i.gender || i.Gender));
  }
  if (filters.ageRange && filters.ageRange.length === 2) {
    const [min, max] = filters.ageRange;
    out = out.filter(i => {
      const age = Number(i.age || i.Age || 0);
      return age >= min && age <= max;
    });
  }
  if (filters.categories && filters.categories.length) {
    out = out.filter(i => filters.categories.includes(i.productCategory || i.ProductCategory));
  }
  if (filters.tags && filters.tags.length) {
    out = out.filter(i => {
      const t = i.tags || i.Tags || '';
      const tags = Array.isArray(t) ? t : String(t).split(',').map(x => x.trim());
      return filters.tags.every(ft => tags.includes(ft));
    });
  }
  if (filters.paymentMethods && filters.paymentMethods.length) {
    out = out.filter(i => filters.paymentMethods.includes(i.paymentMethod || i.PaymentMethod));
  }
  if (filters.dateFrom || filters.dateTo) {
    const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
    const to = filters.dateTo ? new Date(filters.dateTo) : null;
    out = out.filter(i => {
      const d = new Date(i.date || i.Date);
      if (isNaN(d)) return false;
      if (from && d < from) return false;
      if (to && d > to) return false;
      return true;
    });
  }
  return out;
}

function applySort(items, sort) {
  // sort: e.g. 'date_desc' | 'quantity_desc' | 'customer_asc'
  if (!sort) return items;
  const [field, dir] = sort.split('_');
  const order = dir === 'desc' ? 'desc' : 'asc';
  return _.orderBy(items, item => {
    if (field === 'date') return new Date(item.date || item.Date).getTime() || 0;
    if (field === 'quantity') return Number(item.quantity || item.Quantity || 0);
    if (field === 'customer') return String(item.customerName || item.CustomerName || '').toLowerCase();
    return item[field];
  }, [order]);
}

async function query({ search, filters, sort, page = 1, pageSize = 10 }) {
  const data = loadData();
  let items = data;

  // 1. search
  items = applySearch(items, search);
  // 2. filters
  items = applyFilters(items, filters);
  // 3. sort
  items = applySort(items, sort);
  // 4. pagination
  const totalItems = items.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const start = (safePage - 1) * pageSize;
  const paged = items.slice(start, start + pageSize);

  return { data: paged, page: safePage, pageSize, totalPages, totalItems };
}

module.exports = { query };
