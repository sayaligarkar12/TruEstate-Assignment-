Place the provided sales dataset here as `sales.json`.
If you only have CSV, convert to JSON with a simple script or use an npm CSV parser and adjust loader in queryService.
