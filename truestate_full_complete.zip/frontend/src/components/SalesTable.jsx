import React from 'react'
export default function SalesTable({ rows }){
  if (!rows || !rows.length) return <div>No results found.</div>
  return (
    <table className="sales-table">
      <thead>
        <tr>
          <th>Date</th>
          <th>Customer</th>
          <th>Phone</th>
          <th>Product</th>
          <th>Quantity</th>
          <th>Final Amount</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i)=> (
          <tr key={i}>
            <td>{new Date(r.date||r.Date).toLocaleDateString()}</td>
            <td>{r.customerName || r.CustomerName}</td>
            <td>{r.phoneNumber || r.PhoneNumber}</td>
            <td>{r.productName || r.ProductName}</td>
            <td>{r.quantity || r.Quantity}</td>
            <td>{r.finalAmount || r.FinalAmount}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
