import React, { useState } from 'react'

export default function FilterPanel({ value, onChange }){
  const [regions, setRegions] = useState(value.regions || [])
  const [genders, setGenders] = useState(value.genders || [])
  const [ageMin, setAgeMin] = useState(value.ageRange ? value.ageRange[0] : '')
  const [ageMax, setAgeMax] = useState(value.ageRange ? value.ageRange[1] : '')

  function apply(){
    const filters = {}
    if (regions.length) filters.regions = regions
    if (genders.length) filters.genders = genders
    if (ageMin !== '' || ageMax !== '') filters.ageRange = [Number(ageMin||0), Number(ageMax||120)]
    onChange(filters)
  }

  function toggle(arr, setter, val){
    if (arr.includes(val)) setter(arr.filter(x=>x!==val))
    else setter([...arr, val])
  }

  return (
    <aside className="filters">
      <h3>Filters</h3>
      <div>
        <strong>Region</strong>
        <div>
          {['North','South','East','West'].map(r=> (
            <label key={r}><input type="checkbox" checked={regions.includes(r)} onChange={()=>toggle(regions,setRegions,r)} /> {r}</label>
          ))}
        </div>
      </div>
      <div>
        <strong>Gender</strong>
        <div>
          {['Male','Female','Other'].map(g=> (
            <label key={g}><input type="checkbox" checked={genders.includes(g)} onChange={()=>toggle(genders,setGenders,g)} /> {g}</label>
          ))}
        </div>
      </div>
      <div>
        <strong>Age Range</strong>
        <div>
          <input placeholder="min" value={ageMin} onChange={e=>setAgeMin(e.target.value)} />
          <input placeholder="max" value={ageMax} onChange={e=>setAgeMax(e.target.value)} />
        </div>
      </div>
      <button onClick={apply}>Apply</button>
      <button onClick={()=>{ setRegions([]); setGenders([]); setAgeMin(''); setAgeMax(''); onChange({}) }}>Clear</button>
    </aside>
  )
}
