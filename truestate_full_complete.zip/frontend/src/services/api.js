import axios from 'axios'
const API = 'http://localhost:4000/api/sales'

export async function fetchSales({ q, filters, sort, page, pageSize = 10 }){
  const params = { q, sort, page, pageSize };
  if (filters && Object.keys(filters).length) params.filters = JSON.stringify(filters);
  const res = await axios.get(API, { params });
  return res.data;
}
