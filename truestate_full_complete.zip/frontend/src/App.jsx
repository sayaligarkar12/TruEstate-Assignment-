import React, { useEffect, useState } from 'react'
import SearchBar from './components/SearchBar'
import FilterPanel from './components/FilterPanel'
import SalesTable from './components/SalesTable'
import Pagination from './components/Pagination'
import { fetchSales } from './services/api'

export default function App(){
  const [query, setQuery] = useState('')
  const [filters, setFilters] = useState({})
  const [sort, setSort] = useState('date_desc')
  const [page, setPage] = useState(1)
  const [data, setData] = useState({ data: [], page:1, totalPages:1, totalItems:0 })

  const load = async () =>{
    const res = await fetchSales({ q: query, filters, sort, page })
    setData(res)
  }

  useEffect(()=>{ setPage(1) }, [query, filters, sort])
  useEffect(()=>{ load() }, [query, filters, sort, page])

  return (
    <div className="container">
      <h1>TruEstate — Sales Dashboard</h1>
      <SearchBar value={query} onChange={setQuery} />
      <div className="main">
        <FilterPanel value={filters} onChange={setFilters} />
        <div className="content">
          <div className="toolbar">
            <label>Sort: </label>
            <select value={sort} onChange={e=>setSort(e.target.value)}>
              <option value="date_desc">Date (Newest)</option>
              <option value="quantity_desc">Quantity (High)</option>
              <option value="customer_asc">Customer (A–Z)</option>
            </select>
          </div>
          <SalesTable rows={data.data} />
          <Pagination page={data.page} totalPages={data.totalPages} onPageChange={setPage} />
        </div>
      </div>
    </div>
  )
}
