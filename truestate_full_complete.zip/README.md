# TruEstate - Retail Sales Management System

## Overview
Full-stack Retail Sales Management System implementing full-text search, multi-select filters, sorting, and pagination for sales data.

## Tech Stack
- Backend: Node.js, Express
- Frontend: React, Vite

## Run locally
1. Backend
   - `cd backend`
   - `npm install`
   - place dataset as `backend/data/sales.json` (or `sales.csv` and update loader)
   - `npm start`
2. Frontend
   - `cd frontend`
   - `npm install`
   - `npm run dev`

Backend runs on `http://localhost:4000` and frontend on `http://localhost:3000` (or Vite dev port).
