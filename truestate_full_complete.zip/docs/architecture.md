# Architecture

## Backend
- Express server exposing `/api/sales`.
- Single `QueryService` implements search, filter, sort, pagination in a deterministic pipeline.

## Frontend
- React app with components for Search, Filters, Table, Pagination.
- Frontend preserves state (search, filters, sort, page) and sends them to backend as query params.

## Data Flow
1. User interacts with UI -> App state updated.
2. App calls backend `/api/sales` with `q`, `filters`(json), `sort`, `page`.
3. Backend runs unified pipeline and returns paginated response.
